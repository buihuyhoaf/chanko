# Traceability Matrix
[Matrix34×6 tài liệu](traceability_matrix.csv):34 ID ×6 surfaces =204 ô so sánh; cả204 ô là INSUFFICIENT EVIDENCE do thiếu body decision. Không coi có11 states hoặc20/29 AC là34 decisions đã MATCH.

- MATCH: body VERIFIED, rule được cover đầy đủ và không trái nguồn.
- MISSING COVERAGE: body có đủ bằng chứng cho yêu cầu nhưng một tài liệu/AC không cover.
- CONFLICT: có nội dung trái trực tiếp giữa rule đã đọc và handoff; ghi2 source cụ thể.
- INSUFFICIENT EVIDENCE: chưa đủ body hoặc bằng chứng để kết luận3 trạng thái trên.

Các gap R02/R03/R04/R06/R08/R09 đã được sửa theo SPEC/TECH/request có nguồn trong tài liệu v0.3; đó là coverage reconciliation, không phải MATCH theo CHAT/GAP/FINAL. R05 là portable packaging fix, không chứng minh canonical asset. R01 còn mở; R07 là production contract gate.

## Coverage nguồn có nội dung (không gán decision ID)
| Rule source | UX | Nav | State | Contracts | Edge cases | AC |
|---|---|---|---|---|---|---|
| U01 shell | Scope | Entry points | Scaffold context | ChatScaffold | Back/account | AC01 |
| U02 / SPEC01 verdict & history | Item Chat + persistence clarification | ItemDetail return | S03 + subcase | Evaluate/history boundaries | EC09/17/19/29/30 | AC04–07/21–23 |
| U03 / ADR09 offline | Offline | Reconnect no post | S06/S08 | cache/reconcile seam | EC06–08/34 | AC08/29 |
| U04 delete preservation | gated copy | options→ack | S10/S11 | DeleteDialog, independent history | EC13–16/31 | AC11/12/24/27 |
| U05 / TECH03 retry | UnknownOutcome | lifecycle return | request flags | key/payload/IDs | EC02–05/32 | AC09/10/28 |
| U06 / SPEC07 mascot | canonical/a11y | no extra route | fallback | ChankoCompanion | EC21/27 | AC05/07/17/18 |
| B03 MyItems Ready | boundary | Ready entry + Back | context overlay | no marker mutation | EC11/31 | AC25/27 |

Coverage trên là document review, chưa runtime PASS. Delete/multi-device/cursor behavior cần contract tại12; v0.3 không giả đáp án cho missing API/Data.
