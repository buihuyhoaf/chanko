# Acceptance Criteria
Đây là kế hoạch kiểm thử cho coding agent tương lai; không phải runtime test đã pass. AC được đặt mới cho handoff, không map giả sang CHAT-01–20/GAP/FINAL.

| AC | Given / When | Then / bằng chứng |
|---|---|---|
| AC01 | App shell mở Chat từ Home/Item Detail | Vẫn đúng 4 tabs, không Chat tab5; Back trả nguồn và filters/scroll |
| AC02 | Chọn FX01–FX12 | Render đủ 11 UX states S01–S11, kể cả offline no-cache và partial error |
| AC03 | Fake mode bất kỳ | Nhãn bản mẫu luôn thấy; replies dựng sẵn; không request AI/network; không ghi business thật |
| AC04 | Free Chat gửi “đã mua”, “skip”, “wait” | Không tạo ShoppingItem, Decision/Evaluation official, Purchase hoặc đổi budget/status |
| AC05 | Item fixture có BUY/WAIT/SKIP | Card đúng rationale/context/time, BUY neutral; chỉ đọc advice, zero business side effect |
| AC06 | User đi từ verdict sang Item Detail | Ghi mua/chờ/skip qua flow hiện có với xác nhận; Chat không nhân đôi flow hoặc tự xác nhận |
| AC07 | Re-evaluate, đổi personality, user làm trái advice | History cũ immutable; official choice từ item domain, giọng không đổi logic verdict |
| AC08 | Offline có cache/no-cache | Banner rõ; read cached only; Send/evaluate/delete/archive/restore disabled; reconnect không auto-send |
| AC09 | Double tap/rotate/timeout send | Một operation, một user bubble, một terminal assistant; retry cùng key; UnknownOutcome reconcile |
| AC10 | Duplicate/reordered/partial demo events | Dedup đúng IDs/sequences, terminal một lần; partial không sinh verdict |
| AC11 | Delete chat có official item history và purchase | Sau ack chat biến mất, official decisions/evaluations/purchases/budget giữ nguyên; đọc được khi conversation link mất |
| AC12 | Delete Cancel, failure, timeout | Cancel không đổi dữ liệu; failure giữ dialog/context; timeout không báo success hay đổi key bừa |
| AC13 | Archive/Restore fake scenario | Giữ messages/context; không archive/restore item hoặc đổi status; archived read-only theo P |
| AC14 | Item Picker Cancel/select/stale item | Cancel giữ context; select không gán transcript free vào item; stale/404 không tự chọn item khác |
| AC15 | History/message paging và query race | Không trùng/mất stable IDs; stale response không overwrite; total không từ page length |
| AC16 | Account switch/401/owner404 | Không lộ transcript/preview/cache/draft account khác; route unavailable không leak resource |
| AC17 | Font200%, TalkBack, reduced motion, keyboard | Text/tiền/lỗi đủ, focus có nghĩa, touch≥48dp; không announce mỗi token; static fallback |
| AC18 | Mascot thiếu/unsupported emotion | Canonical neutral hoặc text-only; không stock cat; không mascot trong product image |
| AC19 | Invalid schema/AI unavailable/rate limit | Không default BUY hoặc fake success; lỗi và retry đúng category, giữ input |
| AC20 | Technical gate trước real integration | Resolve Q01–Q08 có contract/ADR phù hợp; không invent endpoint/nullability/streaming |

## Evidence cần bàn giao khi implement được giao riêng
- Screenshots 11 states và BUY neutral; font scale, keyboard, offline no-cache.
- Scenario results cho AC01–20: pass/fail/not tested và lý do.
- Boundary checks: chat interaction không gọi item/purchase/budget mutation; fake flavor không chạm provider.
- Repository/operation tests có ý nghĩa: timeout-after-commit, dedup, stale response, account isolation và history preservation. Không cần snapshot test cho mọi label.
- Assets provenance và missing list; source decision reconciliation 34 rows.
- Không gọi demo screenshots, tài liệu QA hoặc fixture-only pass là backend integration pass.

