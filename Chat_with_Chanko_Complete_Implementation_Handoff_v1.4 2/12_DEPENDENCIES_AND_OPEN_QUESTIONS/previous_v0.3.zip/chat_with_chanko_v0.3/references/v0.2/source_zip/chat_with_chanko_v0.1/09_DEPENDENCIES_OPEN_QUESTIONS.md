# Source audit, dependencies và open technical questions
Ngày đọc: 24/10/2026 (Asia/Ho_Chi_Minh). Không sửa nguồn.

## Nguồn và mức chứng cứ
| Nguồn | Đã kiểm tra | Kết quả |
|---|---|---|
| User request hiện tại | Trực tiếp | Xác nhận 34 quyết định và visual v0.2 Approved; 11 states và các guardrails là U |
| Chat “Thiết kế tính năng chat” 6adcba07-ac98-83ec-809a-bdb67c01c757 | read_thread limit10; trả5 turns, hasMore=false | Assistant chỉ content-reference, không có body34 quyết định/ảnh; không thể map từng mã một cách trung thực |
| Functional v1.1 — SPEC-01/07, ADR-09/SPEC-09 và phụ lục cuối | Fetch trực tiếp Drive, snapshot sources/functional.txt | Advice khác decision/status/purchase; Quick Check; canonical cat/9 emotions; online-first |
| TECH-01 v1.1 | Fetch trực tiếp, sources/tech01.txt | Kotlin/Compose/MVVM/Clean; REST thường; không SSE/WebSocket MVP |
| TECH-02 | Fetch trực tiếp, sources/tech02.txt |4.5 Decision Records shopping_item_id;4.6 evaluation item-bound;4.14 conversations item-bound;4.15 message seq/request; không migration đã chạy |
| TECH-03 v1.1 | Fetch trực tiếp, sources/tech03.txt |2.6 create conversation với item_id;5.2 REST non-stream; operation/idempotency; owner/version/errors |
| Design System v1.0 | Snapshot đã có ../chanko_android_v1.0/sources/design_system_v1_0.txt, đọc phần visual/a11y | Candy Pop3D/Nunito/4tabs, canonical; không đủ chứng minh v0.2 pixel parity |
| My Items/Item Detail v1.0 |01/03/06/09 + Recovery Baseline và source snapshots local | ITEM-07 4tabs/global+; DETAIL-05 Journey/DETAIL-14 PurchaseHistory; detail→AI entry và bảo toàn nghiệp vụ |
| Coding standards | Local inventory + Drive query Coding/Standards/Coding Standards + Design folder listing | Không có Android repo/AGENTS trong inventory, chưa tìm được coding standards riêng; chỉ xác minh được kiến trúc TECH-01, không claim đã review tài liệu chưa thấy |
| Home handoff ZIP candidate | Metadata và raw fetch reference | Có file Drive; chưa đọc nội dung, không xác nhận chứa canonical/coding standards |
| Starter pack local | README | Là sound prototype synthesized, không phải visual mascot/canonical approval |

## Links nguồn
- Functional: https://docs.google.com/document/d/1I-H3HP8LwBXYNBkAX85IQFMt3-346t3B-Kak246M8Go/edit
- TECH-01: https://docs.google.com/document/d/1iedDkUbbOWThMm_vDs5RRQ-BKJ6NMDLTkb4YhcTapEI/edit
- TECH-02: https://docs.google.com/document/d/1nLLLfrWpU0tKbrL9YhjKsTZiVcpYZ_5lQ5fgHKY-0dQ/edit
- TECH-03: https://docs.google.com/document/d/1BA6OjK-vDcXEVz0Ejcao7Krg4D9i6qqc5XNMMkSTkDI/edit
- Design System: https://docs.google.com/document/d/1OPZt4JU1WpGYJHL5RIjJYmmx847Cg7Yg/edit
- Home candidate: https://drive.google.com/file/d/1p4nEVvhqA2TcWBO9cToTxU8Eclf-VWjT/view

## Reconciliation — không tự sửa baseline
| ID | Khác biệt/dependency | Hướng xử lý tài liệu này | Gate/owner |
|---|---|---|---|
| Q01 | Free Chat U; TECH-02 conversations/evaluations và TECH-03 creation đang item-bound | FREE/nullable item chỉ logical fake model; không tự đổi FK/API, không tạo dummy official item | Backend architect: free thread schema/create/list/context; chuyển free→item là thread mới hay link explicit? |
| Q02 | Retry streaming U; TECH-01 §12/TECH-03 §5 dùng REST, cấm SSE/WebSocket MVP | REST production baseline; mô phỏng chunks cho QA và dedup contract có điều kiện, không tự bật stream | Product+architect: streaming thật hay hiệu ứng UI? Nếu thật cần ADR override, event/resume/cancel contract |
| Q03 | Thread Options/Delete/Archived U; TECH-03 chỉ nêu create/read/messages/evaluate, chưa rõ lifecycle APIs | UI fake archive/delete/restore P; không đoán endpoint hay hard/soft delete | Backend/data: lifecycle enum, retention, active-operation handling, version/capabilities, archive thread vs item |
| Q04 | Delete chat phải giữ official decisions; evaluation có conversation FK nullable trong TECH-02 | Không cascade; official history đọc qua item; link transcript unavailable có fallback | Data/backend: FK behavior/null/tombstone, evaluation snapshot/rationale retention, security deletion policy |
| Q05 | TECH-03 idempotency/operation có, chưa đủ resume stream, TTL/cancel/concurrent turn | Giữ key và payload, UnknownOutcome reconcile; không invent TTL/endpoint | Backend: lookup/replay operation, terminal state, clientId↔serverId, turn concurrency/version, Retry-After |
| Q06 | History/Archived/global list/picker/cache cần pagination và freshness; contract cũ chủ yếu item query | Logical read models P, không global sort bằng từng page | Backend+Android: cursor/order/count/search, account cache expiry/invalidation và draft retention |
| Q07 |34 bodies/v0.2 canonical asset chưa truy xuất | Giữ approved status theo U; trace rows pending evidence, không gán nội dung tự viết | Product/design custodian: cung cấp body/source export và canonical registry/file; không cần duyệt lại toàn bộ |
| Q08 | Coding standards/Android repo chưa có; serializer còn choice trong TECH-01 | Agent audit repo trước code; dùng architecture baseline, không tự chọn library version | Android lead: repo/AGENTS, lint/format/testing/build commands, serializer convention |
| Q09 |9 SPEC-07 emotions vs8 UI presentation states trong DS; v0.2 mapping chưa có | Whitelist/fallback, giữ enum domain; không đổi theo8 states | Design+Android: canonical emotion/animation map, reduced motion fallback |
| Q10 | Item Detail Ready/Postponed/archive lifecycle còn pending ở handoff v1.0 | Chat không clear Ready/restore item/cancel waiting, dùng flow hiện có | Item domain owners: persisted review markers/archived write capabilities; không mở rộng scope chat |

## Những điểm đã nhất quán, không mở lại
- CHAT không tab5; My Items giữ4tabs/global+, Chat route tích hợp.
- SPEC-01/TECH-02/03 khẳng định verdict không status/purchase; official user action riêng.
- Offline AI cần mạng; local cache không business outbox.
- Purchase/decision history tồn tại độc lập transcript. Delete chat không delete item.
- Phụ lục cuối Functional/TECH-02/03 có hiệu lực hơn đoạn cũ: estimated_unit_price/actual_unit_price, integer quantity; hoàn tất cooling-off tạo COMPLETED/CONSIDERING, Need More Time tạo phiên mới. Không coi các tên actual_price/expected_unit_price cũ là contract hiện hành.

## Decision evidence register
34 rows ở decision_register.csv ghi đúng từng ID CHAT-01–20, GAP-01–08, FINAL-01–06: Approval=User-confirmed; Body=Not retrieved; Mapping=Pending evidence. Không trộn GAP-01–04 của My Items với GAP-01–08 của Chat. Sau khi khôi phục body chỉ cập nhật traceability, đánh dấu divergence và owner, không tự sửa Approved baseline.

