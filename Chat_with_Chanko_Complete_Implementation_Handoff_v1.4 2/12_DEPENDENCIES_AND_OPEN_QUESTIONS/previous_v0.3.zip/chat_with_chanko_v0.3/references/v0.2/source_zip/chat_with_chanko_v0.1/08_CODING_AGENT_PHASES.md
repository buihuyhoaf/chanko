# Coding agent — hướng dẫn theo phase

## Prompt giao việc dùng trực tiếp
Bạn được giao implement UI Chat with Chanko ở một nhiệm vụ riêng. Đọc README và01–09 của handoff này, Functional SPEC-01/07/09, TECH-01/02/03, handoff My Items/Item Detail v1.0 và AGENTS.md/coding standards của repo đích trước khi sửa source. Giữ mọi Approved UX và Candy Pop3D v0.2. Không thêm Chat tab thứ5, không tạo mascot khác, BUY neutral. AI advice không đổi item/purchase/budget; official Decision Records thuộc ShoppingItem; offline cache-only; delete chat giữ official history; retry không duplicate. Backend chưa sẵn sàng: xây UI qua fake repositories/dummy fixtures có nhãn rõ, không giả AI online là chức năng thật. Không tự phát triển backend/schema/API hoặc sửa baseline để khớp UI. Không tạo PR/deploy ngoài authorization của nhiệm vụ được giao. Các P trong handoff là defaults implementation có thể đối chiếu lại; không gắn chúng vào mã Approved khi chưa có body nguồn.

## Phase 0 — Audit và mapping
Inputs: README/09 + repo đích + decision bodies/v0.2 nếu đã có.
Làm: map theme/components/routes/feature modules, DI/cache/account scope, Item Detail entry và history readers. Tìm AGENTS/coding standards; xác minh serializer, formatter/lint, test commands/version catalog theo repo. Không đoán dependency versions.
Output: bảng reuse/new/gap và mapping 34 quyết định sau khi có body. Nếu chưa có body, vẫn báo missing source cụ thể, không hỏi duyệt lại tất cả.
Gate: boundaries hiểu rõ; việc khớp layout v0.2 bị giới hạn nếu chưa có screens/assets.

## Phase 1 — UI skeleton và deterministic fake repositories
Làm: logical models và repository seams theo04; fake data sources được chọn rõ qua cấu hình demo của repo. Không cần tách mọi Gradle module ngay; TECH-01 chỉ hướng phụ thuộc Clean Architecture.
MVVM, Compose/M3, StateFlow, Coroutines, Hilt theo baseline; stateless components nhận state/events, ViewModel điều phối. Không gọi repository/network trực tiếp từ composable.
Output: Empty, Free Chat, item context, app bar/composer/history/picker; fake badge luôn thấy.
Gate: AC01–04, fake không provider/network/business writes.

## Phase 2 — Đủ 11 states và flows
Làm: structured verdict, options/delete/archive/restore fake, offline cache/no-cache, loading/partial/error, back stack, draft isolation, paging fixtures.
Output: screenshots S01–S11 và BUY/WAIT/SKIP; errors/cancel behaviors.
Gate: AC02/05–08/11–15; tuyệt đối không coi fake delete đã xóa dữ liệu cloud. Production lifecycle actions còn Q không dùng fake fallback im lặng.

## Phase 3 — Reliability, lifecycle và accessibility
Làm: stable identity, operation reconciliation, retry/dedup, query race, rotation/process recovery; owner isolation; keyboard/font200%/TalkBack/reduced motion.
Output: scenario tests và QA evidence, asset provenance gaps.
Gate: AC09–10/16–19. Demo stream event harness chỉ để QA; production adapter giữ REST theo TECH-01/03.

## Phase 4 — Contract readiness; chưa bật backend
Làm: giải quyết Q01 Free Chat/item nullability; Q02 streaming; Q03 lifecycle/delete retention; Q04 official history FK; Q05 operation/concurrency; Q06 paging/cache; Q07 source/visual assets; Q08 coding standards.
Output: API mapping thực, OpenAPI/ADR revisions nếu chủ tài liệu ban hành, DTO-to-domain mapping và integration plan. Handoff không tự sửa baseline.
Gate: real API khả dụng + đúng authorization + contract accepted. Thiếu contract báo gap; không hạ UX Approved hoặc ship fake làm thật.

## Phase 5 — Real adapter chỉ khi được giao và gate đủ
Đổi data adapter, giữ UI contracts; server là authority; không dựng LLM client trực tiếp trong app. Validate structured responses, version/idempotency và permissions. REST completed response là mặc định; streaming chỉ bật nếu ADR override đã chốt. Chạy contract/integration tests, verify no cascade official history khi delete; không gọi fixture tests là production pass.
Báo những gì implement/verified/not tested, backend blockers và asset missing. Không tự merge/publish/deploy.

## Coding standards đã biết và giới hạn
Baseline kiến trúc: Kotlin/Compose/M3, MVVM/Clean Architecture, Hilt, Coroutines/StateFlow, Retrofit/OkHttp, Room read cache, Gradle Kotlin DSL/Version Catalog. TECH-01 chưa chọn Kotlin Serialization hay Moshi. Không có repo Android/source trong workspace này và chưa tìm thấy tài liệu coding standards riêng đáng tin cậy; vì vậy không chứng nhận tuân thủ naming/lint/test conventions cụ thể. Không áp các tiêu chuẩn tự nghĩ thay repo. Dependency direction UI→Domain←Data; không business mutation từ AI text; không secrets/transcripts trong logs.

