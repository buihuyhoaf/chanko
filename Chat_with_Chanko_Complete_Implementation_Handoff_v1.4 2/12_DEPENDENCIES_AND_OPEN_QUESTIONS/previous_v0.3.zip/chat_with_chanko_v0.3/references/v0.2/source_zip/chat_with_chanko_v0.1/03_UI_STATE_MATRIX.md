# UI State Matrix — đúng 11 trạng thái
Đây là 11 trạng thái UX, không phải enum database. Các overlay có thể kết hợp: Offline + Item Chat, Error + History, Loading + Archived. Thứ tự render P: xác thực/context → modal → offline capability → nội dung → loading/error tại vùng liên quan. Không thay cả timeline bằng spinner khi còn cache.

| # | State | Điều kiện / nội dung | Actions | Exit / guard |
|---|---|---|---|---|
| S01 | Empty | Online, ngữ cảnh mới chưa có message; Chanko canonical nếu có, lời mời ngắn, demo badge | Nhập/gửi, chọn item, History | Gửi tạo pending operation; Empty không chứng minh account chưa có history |
| S02 | Free Chat | Thread không item; messages mẫu có sender và thời gian | Send nếu online/idle; chọn item; History/More | Không official Decision Record; chọn item không gắn ngầm transcript cũ |
| S03 | Item Chat with Verdict | Item context + messages + structured evaluation hoàn tất | Re-evaluate theo quyền; xem item; optional next step qua flow hiện có | BUY/WAIT/SKIP không mutation; stale version có label lịch sử |
| S04 | History | Danh sách active threads; context/free label; empty/partial/page error riêng | Open row, Archived; tải thêm theo cursor | Query cũ không ghi đè; count không giả từ page |
| S05 | Item Picker | Item rows đọc từ repository; query, empty, loading và retry riêng | Select item hoặc Cancel | Item biến mất/stale: refetch, không chọn item khác thay thế; offline chỉ đọc cache, không mở AI |
| S06 | Offline | Banner cache + freshness; timeline/history cached hoặc no-cache explanation | Back/đọc cache; retry kết nối | Send/evaluate và mutations disabled; reconnect không replay |
| S07 | Loading | Initial skeleton hoặc refresh indicator; send pending gắn đúng turn; partial chỉ trong demo scenario | Back/đọc nội dung; cancel UI subscription nếu supported | Không hứa cancel backend; không tạo verdict từ partial; một operation active/thread (P) |
| S08 | Error | Inline section/message error; UnknownOutcome khác confirmed failure | Retry phù hợp, xem lại dữ liệu, Back | Giữ draft/key; validation/conflict không retry mù; no default BUY |
| S09 | Thread Options | Sheet có context thread và quyền hiện tại | P Archive, Delete, xem item; đóng | Online/capabilities guard; không mutate lúc mở menu |
| S10 | Delete Confirmation | Tên/context chat + cảnh báo giữ official history; pending/error trong dialog | Giữ lại / Xóa chat | Double tap một operation; ack mới dismiss success; offline disable; cancel không effect |
| S11 | Archived | List/detail có nhãn archived và message lịch sử | P đọc/Restore/Delete theo capability | Không tự reopen/send; archive chat không archive item; restore không reset history |

## Biến state bổ trợ (P contracts)
content = none/cache/fresh; context = free/item; lifecycle = active/archived/deleted; connectivity = online/offline; request = idle/pending/partial/unknown/failed; modal = none/options/delete/picker; dataSource = fake/cache/server.
Không lưu cả 11 state thành 11 booleans mâu thuẫn. “Deleted” là lifecycle nội bộ để loại route, không thêm trạng thái UX thứ 12. Pending/partial/unknown là request flags, không mở rộng danh sách 11.

## Demo fixtures bắt buộc
FX01 Empty; FX02 Free Chat ≥2 turns; FX03 Item BUY neutral; FX04 cùng item re-evaluation WAIT/SKIP giữ lịch sử; FX05 History nhiều trang; FX06 Picker có/không kết quả; FX07 Offline cache/no-cache; FX08 initial/refresh/send loading; FX09 confirmed error/UnknownOutcome/partial interrupted; FX10 options+delete cancel/ack/failure; FX11 archived+restore; FX12 account switch/stale item/version conflict.
Tất cả là synthetic, không dữ liệu người thật. Fixture money ví dụ 250.000 ₫ chỉ là giá dự kiến, không giả đã chi.

