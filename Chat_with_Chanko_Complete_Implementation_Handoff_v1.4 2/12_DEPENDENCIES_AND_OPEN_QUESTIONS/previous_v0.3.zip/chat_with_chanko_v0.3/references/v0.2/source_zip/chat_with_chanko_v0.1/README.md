# Chat with Chanko — Implementation Handoff v0.1
Ngày: 24/10/2026 · Ngôn ngữ: vi-VN · Chỉ tài liệu, không implementation.

## Cách sử dụng
Đọc theo thứ tự: [nguồn và mâu thuẫn](09_DEPENDENCIES_OPEN_QUESTIONS.md) → [UX](01_UX_SPECIFICATION.md) → [navigation](02_NAVIGATION_FLOW.md) → [11 states](03_UI_STATE_MATRIX.md) → [contracts](04_COMPONENT_CONTRACTS.md) → [edge cases](05_EDGE_CASES.md) → [assets](06_ASSET_MANIFEST.md) → [acceptance](07_ACCEPTANCE_CRITERIA.md) → [coding phases](08_CODING_AGENT_PHASES.md).

## Hiệu lực
- **U — Chỉ thị trực tiếp:** request hiện tại xác nhận CHAT-01–20, GAP-01–08, FINAL-01–06 và Candy Pop 3D v0.2 đã Approved. Không yêu cầu duyệt lại.
- **B — Baseline đọc được:** Functional SPEC-01/07/09, TECH-01/02/03, Design System v1.0 và handoff My Items/Item Detail v1.0.
- **P — Đề xuất implementation:** tên route/component, microcopy, fixture, thứ tự menu, state restoration và cách adapter trong bộ này, nếu chưa có bằng chứng quyết định cụ thể. Đây không phải thay thế Approved UX.
- **Q — Cần contract/nguồn:** body 34 quyết định chưa truy xuất được; không gán nội dung tự viết cho từng CHAT/GAP/FINAL. 11 states và các bất biến từ request được giữ nguyên.

Bộ này dùng trực tiếp để giao UI với fake repositories và dummy data, theo các nhánh P đã đánh dấu. Chưa đủ điều kiện tuyên bố pixel parity với v0.2 hay tích hợp production. Khôi phục nguồn quyết định là gate đối chiếu; không phải hạ cấp các quyết định đã duyệt.

## Phạm vi bàn giao
Không sửa tài liệu baseline, source ứng dụng, backend hoặc tạo PR. Không tạo mascot mới. Không có mã chạy, endpoint mới, database migration hay kết quả kiểm thử runtime trong bundle. Snapshots nguồn chỉ dùng review nội bộ, không ship cùng app.

## Điều kiện bất biến
Chat không là tab thứ năm. AI advice ≠ user decision ≠ item status ≠ purchase. Official Decision Records thuộc Shopping Item. Offline chỉ đọc cache; không gửi/queue/replay. Delete chat không xóa official decision/evaluation history, purchase hay budget. BUY card trung lập. Fake replies luôn được công khai là dữ liệu mẫu.

