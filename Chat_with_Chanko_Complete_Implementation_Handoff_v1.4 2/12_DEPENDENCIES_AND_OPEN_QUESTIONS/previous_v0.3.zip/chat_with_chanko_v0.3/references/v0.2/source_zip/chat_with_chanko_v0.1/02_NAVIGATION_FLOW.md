# Navigation Flow
Tất cả tên route sau là P logical identifiers, không xác nhận routes đã có trong repo.

## Entry points
| Nguồn | Đích | Contract |
|---|---|---|
| Home — CTA Chat (vị trí cần v0.2 xác minh) | ChatEntry → Free Chat/Empty | Không thêm tab; giữ 4 tabs và global + |
| Item Detail — Cân nhắc/Xem lại cùng Chanko | ItemChat(itemId) | Kiểm tra owner/item hiện tại; reuse/new policy là Q |
| Ready — Still Want It | ItemChat(itemId, recheck intent) | Cho bỏ qua; mở chat không clear Ready/ghi decision |
| Chat app bar | ChatHistory | Giữ route nguồn, query/scroll |
| Free Chat — chọn item | ItemPicker | Cancel không đổi context |
| ItemPicker chọn item | ItemChat(itemId) | P mở ngữ cảnh riêng; không sửa Free Chat cũ |
| Item chip/verdict link | ItemDetail(itemId) | Không business mutation |
| History row | ChatThread(threadId) | Đọc mode/context từ repo, không tin object cũ |
| Thread More | ThreadOptions → DeleteConfirmation/Archive | Không mở hai modal cùng lúc |
| History — Archived | ArchivedThreads → ArchivedThread | Khác ArchivedItems |
| Restore thành công | Thread view/History refreshed | Không restore Shopping Item ngầm |
| Delete thành công | History hoặc Empty | Không quay lại deleted route |

## Luồng chính
Home → Empty → gửi hợp lệ → Free Chat.
Item Detail → Item Chat → Quick Check → structured verdict → xem Item Detail → user tự chọn action nghiệp vụ riêng.
History → thread → options → delete confirmation → pending → ack → History.
History → thread → options → archive → ack → Archived → restore rõ ràng.
Bất kỳ view có cache → mất mạng → Offline read-only → có mạng → refetch/reconcile → online state; không tự gửi.

## Back stack và lifecycle (P)
Back ưu tiên đóng keyboard theo hành vi Android, dialog/sheet/picker, rồi route. Cancel delete giữ thread. Back từ Chat về đúng Home/Item Detail và giữ list filters/scroll. Không đẩy Home mới vào stack.
Routes truyền ID và entry intent tối thiểu; repository lấy dữ liệu mới. Không nhét toàn bộ transcript/PII vào navigation args.
Composer draft keyed theo account+thread/context; không rò draft giữa Free/Item/thread. Rotation không gửi lại operation. Process death nếu mất operation identity thì đọc messages/reconcile trước khi cho resend, không đoán chưa commit.
Deep link thread thiếu/không thuộc owner: màn không tồn tại chung, không leak title/preview; Back an toàn. Account switch hủy subscription và xóa view/cache account cũ khỏi màn.
Q: composer dirty khi chuyển context/Back và scope persistence cần kiểm tra Approved body; P demo giữ draft riêng trong session, không tự discard hay persist cloud.

