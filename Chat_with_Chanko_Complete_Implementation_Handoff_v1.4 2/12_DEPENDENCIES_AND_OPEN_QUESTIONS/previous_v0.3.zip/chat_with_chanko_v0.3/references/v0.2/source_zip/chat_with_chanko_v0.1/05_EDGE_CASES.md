# Edge Cases
Các xử lý P chỉ để chốt demo/UI; policy production còn Q ở09.

| ID | Tình huống | Kết quả mong đợi | Bảo toàn |
|---|---|---|---|
| EC01 | Gửi whitespace, paste dài vượt limit thật | Không gửi rỗng; length error giữ input, không tự cắt | Không tạo operation vô nghĩa |
| EC02 | Double tap Send / rotate khi pending | Một user bubble và một operation | Cùng key, không duplicate |
| EC03 | Response mất sau commit | UnknownOutcome, reconcile cùng intent | Không gửi lại key mới |
| EC04 | Stream demo ngắt/duplicate/out-of-order | Partial chưa có verdict; replay dedup/sequence | Không hai assistant bubbles/terminal |
| EC05 | Back khi đang trả lời | Rời view an toàn; load lại/reconcile khi quay lại | UI cancel không tuyên bố backend canceled |
| EC06 | Offline trước send | Disable + lý do, giữ text đang nhập | Không message/outbox/AI giả online |
| EC07 | Mất mạng giữa request | Cache đọc được; pending/unknown khi chưa biết kết quả | Không auto replay reconnect |
| EC08 | Offline no-cache | “Chưa có dữ liệu lưu trên thiết bị” | Không gọi account empty |
| EC09 | Item sửa giá/status trong chat | Refresh context; verdict cũ ghi lịch sử/stale | Không silently recompute verdict |
| EC10 | Item deleted/unavailable/khác owner | Safe unavailable, không leak title; không send/evaluate | Không tự tạo lại item |
| EC11 | Item archived / Waiting hết hạn | Chat hiển thị snapshot có nhãn; quyền theo contract | Không cancel timer/clear Ready tự động |
| EC12 | Thread archived trên thiết bị khác | Refresh version/capability trước send | Không tự restore |
| EC13 | Delete đang pending bị timeout | Giữ UnknownOutcome, reconcile; không báo xóa chắc chắn | Official history/purchases còn nguyên |
| EC14 | Delete Cancel/Back | Đóng dialog về thread | Không mutation |
| EC15 | Delete chat có evaluation | Transcript bị xóa theo retention contract; item history vẫn đọc được | Link conversation mất có fallback, không cascade |
| EC16 | Restore archived chat | Message/context/history giữ, item archive/status không đổi | Không tạo thread clone |
| EC17 | Free Chat nói “mua rồi” | Chỉ message, mời dùng flow ghi nhận riêng nếu có | Không purchase/decision/budget |
| EC18 | Free Chat chọn item | P mở item context riêng, giữ thread free | Không gắn retroactive transcript |
| EC19 | BUY trái quyết định SKIP của user | Giữ cả advice và official choice đúng nguồn | Không shaming/ghi đè history |
| EC20 | Personality đổi giữa thread | Giọng mới cho phản hồi mới, kết luận lịch sử giữ nguyên | Không sửa old verdict |
| EC21 | Payload invalid/unknown verdict/emotion | Reject invalid verdict; emotion fallback canonical neutral | Không default BUY/mèo khác |
| EC22 | 401, 404, 409, 422, 429, 503/504 | Reauth theo app; safe unavailable; reconcile conflict; inline validation; rate limit retry theo server; AI unavailable | Không retry vô hạn, không expose raw error |
| EC23 | Account switch/logout | Hủy subscriptions, clear rendered data/drafts theo policy, caches owner-scoped | Không rò thread giữa accounts |
| EC24 | Long title/text, font200%, keyboard | Wrap/scroll, CTA tiếp cận được, tiền/lỗi không cắt | Touch≥48dp/TalkBack |
| EC25 | Pagination refresh/query đổi | Reset cursor phù hợp, bỏ stale response, stable dedup | Không thiếu/trùng thread/message |
| EC26 | Empty rationale/missing budget/history | Nêu thiếu dữ liệu hoặc lỗi schema; không bịa con số | Không insight/decision giả |
| EC27 | Mascot/font asset thiếu | Text-only báo gap; theme/font fallback chỉ trong preview có ghi rõ | Không dùng mèo ngẫu nhiên |
| EC28 | New message khi đọc history phía trên | Giữ scroll, indicator jump to latest | Không giật màn, announce không mỗi token |

