# Review thực tế ZIP v0.1

## Phân loại
P0: sai lệch đã có bằng chứng dẫn tới mất official history/tiền/quyền riêng tư nghiêm trọng trong deliverable. Chưa phát hiện P0 ở mức tài liệu. P1: chặn việc giao implementation chính xác hoặc sign-off; P2: làm rõ tài liệu/QA. Đây không phải audit runtime.

## P1

| ID | Mức | Vấn đề | Bằng chứng v0.1 | Ảnh hưởng | Sửa/giữ gate | Trạng thái v0.2 |
|---|---|---|---|---|---|---|
| R01 | P1 | Thiếu đối chiếu nội dung 34/34 | decision_register.csv:2–35; 09 Q07 | Cả 34 dòng chỉ Not retrieved/Pending evidence. Lịch sử hiện trả content-reference, không có body. Không thể xác nhận match hay mismatch cụ thể từng mã. | Giữ approval do user xác nhận; mỗi dòng v0.2 có verdict NOT_VERIFIABLE, không gán nội dung từ AC hoặc My Items. Chặn sign-off 34/34; cần export body gốc. | OPEN — thiếu nguồn |
| R02 | P1 | Item Chat chưa có verdict thiếu case rõ | `03_UI_STATE_MATRIX.md:8` | S03 chỉ nhận structured evaluation hoàn tất; S01 chỉ empty và S02 chỉ free. Item thread đang Quick Check có messages nhưng chưa có verdict không có case được định nghĩa rõ; S07 chỉ pending không thay được idle question. | Giữ đúng 11 state cấp cao; bổ sung biến thể S03 chưa có verdict và fixture/AC21 trong hiệu chỉnh. Đây là hoàn thiện coverage SPEC-01, không tự tuyên bố đổi tên state Approved. | FIXED IN OVERLAY |
| R03 | P1 | Yêu cầu verdict sớm thiếu action/event/AC cụ thể | `01_UX_SPECIFICATION.md:22`; `04_COMPONENT_CONTRACTS.md:14` | UX nói có verdict sớm nhưng contracts không có event yêu cầu đầu tiên/early verdict; navigation/AC không có scenario tương ứng. SPEC-01 và TECH-03 §5.1/5.2 yêu cầu user được yêu cầu sớm. | Bổ sung intent RequestEarlyVerdict, fixture/AC22 và mapping evaluate hiện hữu. Label/placement là P, không tự thêm endpoint. | FIXED IN OVERLAY |
| R04 | P1 | Gate bỏ sót Q09/Q10 | `07_ACCEPTANCE_CRITERIA.md:25`; `08_CODING_AGENT_PHASES.md:29` | AC20 và Phase4 chỉ Q01–08 dù 09 liệt kê Q09 emotion mapping và Q10 Ready/Postponed/archive. Có thể đánh dấu gate pass khi các dependency có ảnh hưởng vẫn mở. | Đổi thành gate theo capability và cả Q01–Q10; tách visual sign-off khỏi backend readiness, không buộc mọi feature phải đợi toàn bộ Q. | FIXED IN OVERLAY |
| R05 | P1 | Gói chưa tự đủ dependency kiểm chứng | `06_ASSET_MANIFEST.md:14`; `09_DEPENDENCIES_OPEN_QUESTIONS.md:13` | ZIP không chứa DS, My Items recovery và placeholder được dẫn bằng ../chanko_android_v1.0. qa broken_relative_links=[] không kiểm semantic references dạng text/table nên không chứng minh portable. | Đóng gói evidence dependency có checksum; xác minh đường dẫn placeholder tồn tại. Không coi đó là mascot canonical; đường dẫn portable ở overlay. | FIXED IN OVERLAY |
| R06 | P1 | Cụm zero business side effect dễ loại nhầm lưu evaluation | `07_ACCEPTANCE_CRITERIA.md:10`; `04_COMPONENT_CONTRACTS.md:27` | TECH-02 §4.6 và TECH-03 §5.1/5.3 yêu cầu lưu messages/evaluation hợp lệ. AC05 và boundary checks quá rộng nếu hiểu Chat không được ghi bất kỳ domain record nào. Đây là wording ambiguity, chưa có bằng chứng app làm sai. | Làm rõ cấm tự đổi item/decision/purchase/budget/cooling-off; vẫn lưu message và immutable evaluation qua server orchestrator. Tap card/read không tạo evaluation mới. | FIXED IN OVERLAY |
| R07 | P1 | Guarantee history sau delete chưa có contract chứng minh | `01_UX_SPECIFICATION.md:31`; 09 Q03/Q04 | Delete dialog nói official history được giữ, nhưng FK nullable không chứng minh ON DELETE hay history reader độc lập transcript. v0.1 đã ghi Q03/Q04, đây là dependency blocker được xác nhận lại, không lỗi mới bị che giấu. | Giữ invariant và demo rõ nhãn; production delete chỉ enable khi retention/FK/capability được chốt và test độc lập. Không tự chọn hard/soft delete/SET NULL/cascade. | OPEN — cần contract |

## P2

- R08 — EC22 liệt kê 401/404/409/422/429/503/504 nhưng thiếu 403/428 trong TECH-03 §6.3. Bổ sung AC26: 403 hiển thị không có quyền, 428 không retry mù khi thiếu version. Không kết luận v0.1 không hỗ trợ chỉ vì bảng không liệt kê; đây là thiếu coverage tài liệu.
- R09 — AC09 yêu cầu “một terminal assistant” cho cả confirmed failure. Sửa thành tối đa một assistant terminal thành công cho cùng operation; trường hợp thất bại hợp lệ có thể không có assistant. Pending/UnknownOutcome không được giả completion.

## Review từng phần

| File | Kết quả |
|---|---|
| README.md | Phân biệt U/B/P/Q tốt, scope/no-code đúng. Câu dùng trực tiếp cho UI cần đọc kèm gate thiếu nguồn, không Approved 34/34. |
| 01_UX_SPECIFICATION.md | Ranh giới advice/purchase, free mock, cache-only, BUY neutral phù hợp. Các P free→item thread riêng, archived read-only, suggestion fill chưa được chứng minh bằng body Chat. R03/R06/R07 cần hiệu chỉnh. |
| 02_NAVIGATION_FLOW.md | ID-only routes, Back/context/owner tốt; route logical P. Reuse/new, dirty draft và Ready resolution còn mở, không tự chốt. |
| 03_UI_STATE_MATRIX.md | Đủ 11 rows; overlay model hợp lý. R02 là lỗ coverage pre-verdict; FX list 12 scenarios không mâu thuẫn 11 states. |
| 04_COMPONENT_CONTRACTS.md | Hầu hết logical models ghi P rõ. R03/R06; Request/reconcile không là endpoint đã có. Nullable item không thể dùng như schema production. |
| 05_EDGE_CASES.md | 28 case, bao gồm UnknownOutcome, stale, privacy, cascade guard. R08; lifecycle retention chỉ điều kiện, chưa verified. |
| 06_ASSET_MANIFEST.md | Không file mascot/ảnh visual/font kèm; fallback text-only đúng. R05; các tên NEUTRAL/SUPPORTIVE là slot logic, không canonical chứng nhận. |
| 07_ACCEPTANCE_CRITERIA.md | 20 AC là test plan, chưa chạy; R03/R04/R06/R09. Cần scenario item chat chưa verdict. |
| 08_CODING_AGENT_PHASES.md | Fake/real adapter tách rõ, chưa cho phép thực thi code trong nhiệm vụ hiện tại. R04; Phase0 phải giữ 34-row evidence gate. |
| 09_DEPENDENCIES_OPEN_QUESTIONS.md | Nhận đúng Free Chat/item-bound, REST/stream, delete/history và Ready/archive gaps. Q09 là vocabulary mapping, không conflict phải đổi enum. Q05 không có lookup/resume endpoint xác nhận. |
| decision_register.csv | Đúng 34 ID duy nhất, sai lệch nội dung từng quyết định chưa xác định; R01. |
| qa/bundle_integrity.json | 15 hash đúng, 10 markdown/34 decisions/11 state/4 source đúng. broken_relative_links=[] có phạm vi hẹp; R05. |
| sources/functional.txt | Đã đọc SPEC-01/07, ADR09/SPEC09 và phụ lục ưu tiên; khớp fetch lại Drive. |
| sources/tech01.txt | Đã kiểm kiến trúc, 9 emotions, REST no SSE/WebSocket; snapshot-only lần review này. |
| sources/tech02.txt | Đã kiểm toàn văn mô hình dự kiến và phụ lục, item-bound, immutable eval/history/idempotency; khớp fetch lại. Không nâng data dictionary thành DDL Approved. |
| sources/tech03.txt | Đã kiểm API AI/item/history, idempotency/version/errors/REST và phụ lục; khớp fetch lại. Không có lifecycle/free-thread/resume contract hoàn chỉnh. |

## Các giả định phải giữ là P/Q

Menu Archive/Delete, archived read-only, mở item thread riêng khi chọn item, reuse/new, fill-vs-send suggestions, draft session persistence, scroll behavior, một operation active/thread và microcopy/layout không được tự map thành CHAT/GAP/FINAL. Các biện pháp chống duplicate/owner isolation vẫn có baseline TECH làm căn cứ; chi tiết event/cursor/lookup chưa chốt không tự thành API.

## Giới hạn chứng cứ

Hội thoại 6adcba07-ac98-83ec-809a-bdb67c01c757: read_thread turnLimit10 trả 5 turns (3 câu user chấp thuận ngắn, một mô tả bàn giao và một attachment); assistant chỉ content-reference; hasMore=false. Không còn cursor để tải body cũ hơn. Attachment ZIP chính là bản được mở. Không dùng nội dung tự mô tả của ZIP làm bằng chứng độc lập rằng 34 body đã reconciled.

Không mở rộng review sang Home ZIP candidate vì chưa có căn cứ đó là nguồn quyết định Chat hoặc canonical; không dùng starter-pack sound làm visual approval. Không xác nhận pixel parity, TalkBack, build, API, FK, retention hoặc tính bền vững process-death bằng review tài liệu.
