# Hiệu chỉnh bàn giao v0.2 — có hiệu lực khi đọc cùng v0.1
Các mục này sửa coverage/wording/gates dựa trên nguồn đọc được. Không thay quyết định UX Approved chưa khôi phục; không ghi lại baseline. Mọi vị trí/control/copy mới là P trừ hành vi SPEC/TECH được viện dẫn.

## Item Chat trước và sau verdict — R02/R03
Giữ 11 state IDs. S03 là nhóm Item Chat, gồm `evaluation=none/pending/completed/failed/stale` (biến logical P, không enum API). Nếu đang trả lời Quick Check, có item và messages nhưng chưa có verdict: render timeline/composer/suggested answers, không dựng card rỗng. Loading/Error vẫn là overlays S07/S08. “Item Chat with Verdict” cũ chỉ là biến thể completed; chưa chứng minh tên state Approved đã thay đổi.

Thêm intent logical `RequestEarlyVerdict(itemId, conversationId, operationIdentity, contextVersion khi có)`. User có quyền yêu cầu verdict sớm theo SPEC-01; vị trí/label của control chưa có body Chat, giữ P. Chỉ khả dụng online với item/owner và capability hợp lệ. Event đi repository/orchestrator; endpoint evaluate hiện nêu tại TECH-03 §2.6/5.2 với request_early_verdict=true là mapping tham chiếu, không cam kết DTO đầy đủ. Không bắt đủ 3 câu mới được yêu cầu; cũng không bắt AI trước khi mua. Không fake verdict khi input không đủ hoặc lỗi.

Free Chat không được gọi official evaluate bằng item giả. Chọn item vẫn là proposal thread riêng cho demo, production reuse/link/new cần nguồn/contract.

## Phạm vi ghi dữ liệu — R06
Server orchestration được lưu message và Evaluation Record hợp lệ, mỗi lần re-evaluate là bản ghi mới. Hiển thị/tap verdict không tạo thêm evaluation hay official user Decision Record. LLM prose/AI verdict không tự thay item status, purchase, budget hoặc cooling-off. User decision cần action rõ qua item flow. Fake adapter chỉ ghi fixture.

AC05 sửa: BUY/WAIT/SKIP card hiển thị đúng nguồn/context/time; việc render không tạo side effect. Evaluation được lưu bởi evaluate operation hợp lệ; không ghi official decision/purchase/status/budget/cooling-off từ verdict. AC boundary check áp dụng đúng các mutation bị cấm này, không cấm lưu history cần thiết.

## Retry và error — R08/R09
AC09 sửa: một user bubble và một intent/operation; tối đa một assistant terminal thành công cho operation đó. Confirmed failure có thể không có assistant. Không coi pending/partial/unknown là terminal success. Retry cùng intent giữ key/payload trong cửa sổ bảo đảm server; ngoài cửa sổ chưa rõ thì không POST lại mù. Không tự bịa lookup endpoint hoặc TTL.

403 → safe forbidden; không retry mù. 428 → thiếu version/precondition: lấy resource/version theo contract và yêu cầu xem lại trước mutation, không bỏ If-Match để gửi lại. Giữ 401/owner404/409/422/429/503/504 như v0.1.

## Delete/Archive và official history — R07
Delete copy giữ invariant đã yêu cầu, nhưng production action chỉ enable khi capability/retention/FK/history-read semantics được chốt và chứng minh. Nullable conversation FK không đủ xác nhận ON DELETE. Official history phải đọc qua item/evaluation dù transcript không còn, hiển thị unavailable link an toàn. Không tự chọn hard delete, soft delete, tombstone hay SET NULL. Demo dialog phải có nhãn fixture; không hứa đã xóa cloud. Không archive/restore ShoppingItem do archive thread.

## AC và fixtures bổ sung (kế hoạch, chưa chạy)
| ID | Scenario | Kết quả cần chứng minh |
|---|---|---|
| AC21 / FX13 | Item Chat có Quick Check messages, idle, chưa verdict | S03 pre-verdict đọc/gửi được; không card giả; S07 chỉ khi pending |
| AC22 / FX14 | User yêu cầu early verdict trước đủ 3 câu; offline; timeout | Control accessible, online evaluate theo capability, cùng operation khi retry; offline disable; không mutation item/tiền |
| AC23 / FX15 | Evaluation thành công rồi đọc/tap/retry/re-evaluate | Persist hợp lệ đúng một lần/intent; đọc/tap không thêm record; re-evaluate intent mới giữ history cũ |
| AC24 / FX16 | Xóa chat chứa eval và official decision/purchases | Chỉ khi contract gate đủ; item Journey/history vẫn đọc, link unavailable an toàn; ngân sách giữ nguyên |
| AC25 / FX17 | Từ Ready vào Chat, Back/bỏ review; từ Purchased/Skipped mở detail | Không clear Ready khi chỉ mở/Back; Purchased/Skipped read-only priority, mua trực tiếp qua sheet hiện hữu; timing clear chưa chốt không tự set |
| AC26 / FX18 | 403/428 và confirmed send failure không có assistant | Safe error, không retry mù; không tạo assistant/verdict thành công giả |

## Asset/dependency portable — R05
Các bản nguồn dùng review ở `dependencies/my_items/` và `dependencies/design_system_v1_0.txt` (tính từ thư mục v0.2). Placeholder nếu có ở `dependencies/product_placeholder_256.png` chỉ là dummy product đã có, không canonical Chanko. Không asset canonical mới; DS1.0 không chứng minh chat visual0.2.

## Hướng dẫn coding agent sửa — R01/R04
Nhiệm vụ hiện tại chỉ tài liệu. Khi được giao implementation riêng: đọc README v0.2 và overlay trước v0.1, map đủ 34 body nếu đã có; nếu chưa có chỉ chứng nhận prototype coverage, không Approved parity. AC20/Phase4 dùng 03_DEPENDENCY_GATES.md cho Q01–Q10 theo capability; không tick toàn bộ real integration chỉ vì Q01–08 đã đóng.
