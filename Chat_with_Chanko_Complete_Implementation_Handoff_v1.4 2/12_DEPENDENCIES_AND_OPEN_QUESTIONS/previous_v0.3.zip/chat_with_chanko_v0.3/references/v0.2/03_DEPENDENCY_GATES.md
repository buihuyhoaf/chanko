# Đối chiếu dependencies và gate theo capability

## Nguồn và kết quả
| Dependency | Căn cứ cụ thể | Kết luận |
|---|---|---|
| SPEC-01 | Quick Check1–3; early verdict; re-evaluate/history; verdict không status/transaction | Invariants v0.1 đúng, cần pre-verdict/early intent/AC và làm rõ persistence (R02/R03/R06) |
| SPEC-07 | SASSY mặc định; Friendly/Sassy/Savage; 9 emotions; predefined OptionB; truthful context; session/item memory; no sensitive profile | Giữ whitelist 9 domain emotions. Neutral là presentation fallback P, không thêm enum thứ10. Bổ sung QA personality/context không bịa; placement/asset cần nguồn |
| TECH-02 §1/4.5/4.6/4.14/4.15/4.16 | Bảng/cột là thiết kế dự kiến; official decision thuộc item; evaluation có item và conversation ref tùy chọn; conversation item-bound | FREE/null chỉ logical fake. Nullable FK không xác nhận retention. Không biến proposed schema thành migration |
| TECH-03 §2.1/2.6/4.1/4.2/5/6 | REST no streaming; create conversation item_id; list theo item; messages/evaluate; item evaluations; idempotency/version/errors | Global History/Free/lifecycle cần contract; completed REST có thể dùng UI loading, partial chỉ mô phỏng. Operation ID không tự xác nhận lookup endpoint |
| Functional và TECH phụ lục cuối | Giá chuẩn estimated_unit_price/actual_unit_price; integer qty; completion COMPLETED/CONSIDERING | Không lấy ví dụ cũ tên giá/Need More Time extend completed làm contract mới |
| My Items ITEM-07 | 4 tabs + global+ | Không Chat tab5 hoặc Add/FAB trùng |
| Item Detail DETAIL-05/14 | Journey collapsible và Purchase History là sections | Chat không dựng official history độc lập theo transcript; đọc item-domain records |
| DETAIL-08/12 + MyItems GAP-01/02 | Review bỏ qua được; Ready không clear do mở/Back; Need More Time2 nhánh; Skip Waiting khác Skip item | Vào chat không resolve Ready. Postponed là event/presentation, không status mới; persistence C01 còn mở |
| DETAIL-09/11/13 + EDGE-04/07 | Purchased/Skipped read-only; Purchase Confirmation=Record sheet; direct purchase/Buy Again; offline giữ form | Không ép chat trước mua, không thêm sheet thứ4; Chat chuyển route, user xác nhận riêng |
| EDGE-03/MyItems GAP-03 và C02 | Item archive giữ history/budget, Restore; ACTIVE/overdue permissions chưa chốt | Tách archive chat khỏi archive item; không auto restore/clear/cancel |
| DS1.0 | Nunito/M3/Candy Pop3D/a11y; 8 UI presentation vs9 domain emotions | Q09 là mapping còn thiếu, không xung đột enum cần sửa. DS không là ảnh Chat0.2 |

## Gate thay AC20 / Phase4
| Q | Owner cần chốt | Chặn gì | Cho phép hiện tại |
|---|---|---|---|
| Q01 | Product/backend: Free thread schema/create/list, explicit context transition, reuse/new | Free Chat thật và chuyển context thật | Demo logical FREE có nhãn |
| Q02 | Product/architect: có override streaming hay vẫn REST | Chỉ streaming thật; REST vẫn baseline | REST completed response khi API khác đủ; chunks fixture ghi mô phỏng |
| Q03 | Backend/data: thread lifecycle/capability/version/retention/active-op | Archive/Delete/Restore thật | Fixture lifecycle |
| Q04 | Backend/data: FK deletion và independent history read | Delete production và history-preservation acceptance | Test plan; không tự chọn FK behavior |
| Q05 | Backend/Android: operation reconciliation, TTL/window, concurrency, response IDs | Reliable real send/evaluate khi các chi tiết cần thiết chưa đủ | Deterministic demo; giữ TECH idempotency, không invent lookup |
| Q06 | Backend/Android: global history/order/search/count/cache/draft policy | Global History/Archived và persistence chưa contract | Cursor baseline dùng cho supported lists; demo global |
| Q07 | Product/design custodian: body34 và visual0.2/canonical files | 34/34 sign-off và visual parity | Review invariants/prototype text-only |
| Q08 | Android lead: repo/AGENTS/standards/serializer/build/test | Repo-specific implementation verification | Tài liệu, không code hiện tại |
| Q09 | Design/Android: emotion→canonical asset map/reduced motion | Final mascot acceptance | Text-only; giữ 9 domain emotions |
| Q10 | Item domain owners: Ready/Postponed C01 và archived lifecycle C02 | Các mutation phụ thuộc marker/archived permissions | Chat đọc context, không clear Ready/auto restore |

Một feature chỉ được tích hợp khi các Q áp dụng cho nó đóng bằng source/contract/test phù hợp. Q02 không buộc phát triển streaming, Q09 không cần để review text-only. Không blanket-enable Delete do REST send hoạt động. Mỗi Q cần owner, source revision, capability scope, evidence và residual gaps; chưa có owner cá nhân được xác minh thì dùng vai trò, không bịa tên.

## Bằng chứng live nguồn
SPEC modified2026-10-17T10:10:59.447Z; TECH02 modified2026-10-17T10:11:01.531Z; TECH03 modified2026-10-17T10:11:03.420Z. Fetch lại ngày24/10/2026, khớp snapshot sau normalize BOM/newline/trim; bản fetched ở evidence/live_*.txt. Không gọi snapshot TECH01/DS là live-fetched trong lượt này.
