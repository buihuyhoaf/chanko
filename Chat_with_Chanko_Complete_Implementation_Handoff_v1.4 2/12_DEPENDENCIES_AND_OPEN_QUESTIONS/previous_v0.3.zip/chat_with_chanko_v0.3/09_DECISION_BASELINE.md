# Decision Baseline Recovery v0.3

**Approval giữ nguyên. Recovery chưa hoàn tất: VERIFIED0/34, PARTIAL34/34.** PARTIAL nghĩa có ID/range và user xác nhận Approved, nhưng không có body/option gắn riêng cho ID. Không dùng bản tóm tắt hay AC do agent viết để nâng VERIFIED.

[Register đầy đủ](decision_baseline.csv) có ID, phương án, quy tắc, ảnh hưởng UI/API/Data, AC và evidence từng dòng. Giá trị chưa truy xuất ghi NOT RETRIEVED/UNDETERMINED/UNMAPPED; không điền câu UX suy diễn. Không lấy GAP-01..04 của My Items thay GAP Chat.

## Chuẩn bằng chứng
- VERIFIED: body quy tắc/option thực sự đọc được từ approved source, gắn đúng ID/namespace và đủ thông tin xác định phạm vi. Nếu chỉ một phần body thì vẫn PARTIAL; ghi rõ phần nào thiếu.
- PARTIAL: có mã, range hoặc summary nhưng chưa đủ body/option. Approval và evidence verification là2 cột khác nhau.
- Khi có body: giữ nguyên trích đoạn/option/source message hoặc revision, đối chiếu6 tài liệu; chỉ gắn UI/API/Data/AC trong phần hàm ý có căn cứ. Một UX Approved không tự approve schema/endpoint/transport.

## 34 dòng
| ID | Evidence | Option / UX / impacts / AC | Reconciliation |
|---|---|---|---|
| CHAT-01 | PARTIAL — E01/E02/E03 | Chưa truy xuất body; xem CSV, không suy diễn | INSUFFICIENT EVIDENCE |
| CHAT-02 | PARTIAL — E01/E02/E03 | Chưa truy xuất body; xem CSV, không suy diễn | INSUFFICIENT EVIDENCE |
| CHAT-03 | PARTIAL — E01/E02/E03 | Chưa truy xuất body; xem CSV, không suy diễn | INSUFFICIENT EVIDENCE |
| CHAT-04 | PARTIAL — E01/E02/E03 | Chưa truy xuất body; xem CSV, không suy diễn | INSUFFICIENT EVIDENCE |
| CHAT-05 | PARTIAL — E01/E02/E03 | Chưa truy xuất body; xem CSV, không suy diễn | INSUFFICIENT EVIDENCE |
| CHAT-06 | PARTIAL — E01/E02/E03 | Chưa truy xuất body; xem CSV, không suy diễn | INSUFFICIENT EVIDENCE |
| CHAT-07 | PARTIAL — E01/E02/E03 | Chưa truy xuất body; xem CSV, không suy diễn | INSUFFICIENT EVIDENCE |
| CHAT-08 | PARTIAL — E01/E02/E03 | Chưa truy xuất body; xem CSV, không suy diễn | INSUFFICIENT EVIDENCE |
| CHAT-09 | PARTIAL — E01/E02/E03 | Chưa truy xuất body; xem CSV, không suy diễn | INSUFFICIENT EVIDENCE |
| CHAT-10 | PARTIAL — E01/E02/E03 | Chưa truy xuất body; xem CSV, không suy diễn | INSUFFICIENT EVIDENCE |
| CHAT-11 | PARTIAL — E01/E02/E03 | Chưa truy xuất body; xem CSV, không suy diễn | INSUFFICIENT EVIDENCE |
| CHAT-12 | PARTIAL — E01/E02/E03 | Chưa truy xuất body; xem CSV, không suy diễn | INSUFFICIENT EVIDENCE |
| CHAT-13 | PARTIAL — E01/E02/E03 | Chưa truy xuất body; xem CSV, không suy diễn | INSUFFICIENT EVIDENCE |
| CHAT-14 | PARTIAL — E01/E02/E03 | Chưa truy xuất body; xem CSV, không suy diễn | INSUFFICIENT EVIDENCE |
| CHAT-15 | PARTIAL — E01/E02/E03 | Chưa truy xuất body; xem CSV, không suy diễn | INSUFFICIENT EVIDENCE |
| CHAT-16 | PARTIAL — E01/E02/E03 | Chưa truy xuất body; xem CSV, không suy diễn | INSUFFICIENT EVIDENCE |
| CHAT-17 | PARTIAL — E01/E02/E03 | Chưa truy xuất body; xem CSV, không suy diễn | INSUFFICIENT EVIDENCE |
| CHAT-18 | PARTIAL — E01/E02/E03 | Chưa truy xuất body; xem CSV, không suy diễn | INSUFFICIENT EVIDENCE |
| CHAT-19 | PARTIAL — E01/E02/E03 | Chưa truy xuất body; xem CSV, không suy diễn | INSUFFICIENT EVIDENCE |
| CHAT-20 | PARTIAL — E01/E02/E03 | Chưa truy xuất body; xem CSV, không suy diễn | INSUFFICIENT EVIDENCE |
| GAP-01 | PARTIAL — E01/E02/E03 | Chưa truy xuất body; xem CSV, không suy diễn | INSUFFICIENT EVIDENCE |
| GAP-02 | PARTIAL — E01/E02/E03 | Chưa truy xuất body; xem CSV, không suy diễn | INSUFFICIENT EVIDENCE |
| GAP-03 | PARTIAL — E01/E02/E03 | Chưa truy xuất body; xem CSV, không suy diễn | INSUFFICIENT EVIDENCE |
| GAP-04 | PARTIAL — E01/E02/E03 | Chưa truy xuất body; xem CSV, không suy diễn | INSUFFICIENT EVIDENCE |
| GAP-05 | PARTIAL — E01/E02/E03 | Chưa truy xuất body; xem CSV, không suy diễn | INSUFFICIENT EVIDENCE |
| GAP-06 | PARTIAL — E01/E02/E03 | Chưa truy xuất body; xem CSV, không suy diễn | INSUFFICIENT EVIDENCE |
| GAP-07 | PARTIAL — E01/E02/E03 | Chưa truy xuất body; xem CSV, không suy diễn | INSUFFICIENT EVIDENCE |
| GAP-08 | PARTIAL — E01/E02/E03 | Chưa truy xuất body; xem CSV, không suy diễn | INSUFFICIENT EVIDENCE |
| FINAL-01 | PARTIAL — E01/E02/E03 | Chưa truy xuất body; xem CSV, không suy diễn | INSUFFICIENT EVIDENCE |
| FINAL-02 | PARTIAL — E01/E02/E03 | Chưa truy xuất body; xem CSV, không suy diễn | INSUFFICIENT EVIDENCE |
| FINAL-03 | PARTIAL — E01/E02/E03 | Chưa truy xuất body; xem CSV, không suy diễn | INSUFFICIENT EVIDENCE |
| FINAL-04 | PARTIAL — E01/E02/E03 | Chưa truy xuất body; xem CSV, không suy diễn | INSUFFICIENT EVIDENCE |
| FINAL-05 | PARTIAL — E01/E02/E03 | Chưa truy xuất body; xem CSV, không suy diễn | INSUFFICIENT EVIDENCE |
| FINAL-06 | PARTIAL — E01/E02/E03 | Chưa truy xuất body; xem CSV, không suy diễn | INSUFFICIENT EVIDENCE |

## Quy tắc đã truy xuất, không tự map vào34 mã
Các U dưới đây là nội dung trực tiếp của request bàn giao E01; approval-source là request, không claim body từng decision đã khôi phục. B là SPEC/TECH và MyItems source đọc được.

| Ref | Quy tắc có bằng chứng | UI/API/Data implication | AC v0.3 | Source |
|---|---|---|---|---|
| U01 | Chat không tab5 | Giữ app shell4tabs; không endpoint/schema mới do navigation | AC01 | E01; MyItems ITEM07 |
| U02 | Verdict không tự status/purchase/budget; official decision gắn item | Card read, business action riêng; server lưu evaluation hợp lệ | AC04–07/23 | E01; SPEC01; TECH02 §4.5/4.6 |
| U03 | Offline Chat chỉ đọc cache | Send/evaluate disable, không outbox/replay | AC08/29 | E01; ADR09; TECH03 §4.3 |
| U04 | Delete chat giữ official decision history | Independent history readers; retention/FK chưa đủ contract | AC11/24 | E01; Q03/Q04 |
| U05 | Retry streaming tránh duplicate | Stable identity/dedup là requirement; không approve streaming transport | AC09/10/28 | E01; TECH03 §5 REST |
| U06 | Chanko canonical, BUY neutral | Không mascot thay thế/celebration; text-only khi thiếu file | AC05/18 | E01 |
| U07 | Đủ11 named states, fake repositories/dummy rõ nhãn | State coverage và data source badge, không giả online AI | AC02/03/21 | E01 |
| B01 | Quick Check1–3, early verdict, reevaluate history | RequestEarlyVerdict; immutable evaluation qua orchestrator | AC21–23 | sources/functional.txt SPEC01; TECH03 §5 |
| B02 | SASSY default,9 emotions, OptionB tap, personality không đổi logic | Whitelist/fallback; predefined reactions; no shaming | AC07/17/18 + SPEC07 QA | SPEC07; TECH01 |
| B03 | Ready xem/Back không clear; Purchase/Journey độc lập | Không resolve marker khi mở Chat; purchase dùng sheet hiện có | AC25 | MyItems recovery DETAIL05/08/11/14/GAP01 |

U/B coverage được xác minh ở mức tài liệu, không dùng để thay34 body. Một quy tắc trùng nội dung dự kiến của CHAT nào vẫn không đủ để map nếu nguồn không gắn ID.
