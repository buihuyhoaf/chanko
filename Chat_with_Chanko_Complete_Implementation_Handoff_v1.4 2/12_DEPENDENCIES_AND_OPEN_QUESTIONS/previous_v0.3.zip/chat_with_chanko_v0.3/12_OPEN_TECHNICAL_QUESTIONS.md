# Đối chiếu dependencies và gate theo capability

## Nguồn và kết quả
| Dependency | Căn cứ cụ thể | Kết luận |
|---|---|---|
| SPEC-01 | Quick Check1–3; early verdict; re-evaluate/history; verdict không status/transaction | Invariants v0.1 đúng, cần pre-verdict/early intent/AC và làm rõ persistence (R02/R03/R06) |
| SPEC-07 | SASSY mặc định; Friendly/Sassy/Savage; 9 emotions; predefined OptionB; truthful context; session/item memory; no sensitive profile | Giữ whitelist 9 domain emotions. Neutral là presentation fallback P, không thêm enum thứ10. Bổ sung QA personality/context không bịa; placement/asset cần nguồn |
| TECH-02 §1/4.5/4.6/4.14/4.15/4.16 | Bảng/cột là thiết kế dự kiến; official decision thuộc item; evaluation có item và conversation ref tùy chọn; conversation item-bound | FREE/null chỉ logical fake. Nullable FK không xác nhận retention. Không biến proposed schema thành migration |
| TECH-03 §2.1/2.6/4.1/4.2/5/6 | REST no streaming; create conversation item_id; list theo item; messages/evaluate; item evaluations; idempotency/version/errors | Global History/Free/lifecycle cần contract; completed REST có thể dùng UI loading, partial chỉ mô phỏng. Operation ID không tự xác nhận lookup endpoint |
| Functional và TECH phụ lục cuối | Giá chuẩn estimated_unit_price/actual_unit_price; integer qty; completion COMPLETED/CONSIDERING | Không lấy ví dụ cũ tên giá/Need More Time extend completed làm contract mới |
| My Items ITEM-07 | 4 tabs + global+ | Không Chat tab5 hoặc Add/FAB trùng |
| Item Detail DETAIL-05/14 | Journey collapsible và Purchase History là sections | Chat không dựng official history độc lập theo transcript; đọc item-domain records |
| DETAIL-08/12 + MyItems GAP-01/02 | Review bỏ qua được; Ready không clear do mở/Back; Need More Time2 nhánh; Skip Waiting khác Skip item | Vào chat không resolve Ready. Postponed là event/presentation, không status mới; persistence C01 còn mở |
| DETAIL-09/11/13 + EDGE-04/07 | Purchased/Skipped read-only; Purchase Confirmation=Record sheet; direct purchase/Buy Again; offline giữ form | Không ép chat trước mua, không thêm sheet thứ4; Chat chuyển route, user xác nhận riêng |
| EDGE-03/MyItems GAP-03 và C02 | Item archive giữ history/budget, Restore; ACTIVE/overdue permissions chưa chốt | Tách archive chat khỏi archive item; không auto restore/clear/cancel |
| DS1.0 | Nunito/M3/Candy Pop3D/a11y; 8 UI presentation vs9 domain emotions | Q09 là mapping còn thiếu, không xung đột enum cần sửa. DS không là ảnh Chat0.2 |

## Gate thay AC20 / Phase4
| Q | Owner cần chốt | Chặn gì | Cho phép hiện tại |
|---|---|---|---|
| Q01 | Product/backend: Free thread schema/create/list, explicit context transition, reuse/new | Free Chat thật và chuyển context thật | Demo logical FREE có nhãn |
| Q02 | Product/architect: có override streaming hay vẫn REST | Chỉ streaming thật; REST vẫn baseline | REST completed response khi API khác đủ; chunks fixture ghi mô phỏng |
| Q03 | Backend/data: thread lifecycle/capability/version/retention/active-op | Archive/Delete/Restore thật | Fixture lifecycle |
| Q04 | Backend/data: FK deletion và independent history read | Delete production và history-preservation acceptance | Test plan; không tự chọn FK behavior |
| Q05 | Backend/Android: operation reconciliation, TTL/window, concurrency, response IDs | Reliable real send/evaluate khi các chi tiết cần thiết chưa đủ | Deterministic demo; giữ TECH idempotency, không invent lookup |
| Q06 | Backend/Android: global history/order/search/count/cache/draft policy | Global History/Archived và persistence chưa contract | Cursor baseline dùng cho supported lists; demo global |
| Q07 | Product/design custodian: body34 và visual0.2/canonical files | 34/34 sign-off và visual parity | Review invariants/prototype text-only |
| Q08 | Android lead: repo/AGENTS/standards/serializer/build/test | Repo-specific implementation verification | Tài liệu, không code hiện tại |
| Q09 | Design/Android: emotion→canonical asset map/reduced motion | Final mascot acceptance | Text-only; giữ 9 domain emotions |
| Q10 | Item domain owners: Ready/Postponed C01 và archived lifecycle C02 | Các mutation phụ thuộc marker/archived permissions | Chat đọc context, không clear Ready/auto restore |

Một feature chỉ được tích hợp khi các Q áp dụng cho nó đóng bằng source/contract/test phù hợp. Q02 không buộc phát triển streaming, Q09 không cần để review text-only. Không blanket-enable Delete do REST send hoạt động. Mỗi Q cần owner, source revision, capability scope, evidence và residual gaps; chưa có owner cá nhân được xác minh thì dùng vai trò, không bịa tên.

## Bằng chứng live nguồn
SPEC modified2026-10-17T10:10:59.447Z; TECH02 modified2026-10-17T10:11:01.531Z; TECH03 modified2026-10-17T10:11:03.420Z. Fetch lại ngày24/10/2026, khớp snapshot sau normalize BOM/newline/trim; bản fetched ở evidence/live_*.txt. Không gọi snapshot TECH01/DS là live-fetched trong lượt này.

## Q11 — Multi-device sync / concurrency / invalidation (OPEN)
Owner theo vai trò Backend+Android+Data; chưa có tên cá nhân/contract revision accepted. TECH03 có owner/version/idempotency và cache refresh, không đủ full sync protocol.

| Khía cạnh | Baseline có bằng chứng | Contract cần được chốt | Gate / acceptance evidence |
|---|---|---|---|
| Free Chat | TECH02 conversation gắn item; TECH03 create item_id | FREE creation/context association/reuse/new/thread ownership/list | Q01; integration create/read/list không fake item |
| Streaming | TECH01 §12 và TECH03 §5 REST non-stream, no SSE/WS MVP | Nếu có thay đổi transport cần accepted ADR + event/resume/cancel; chưa quyết định thì giữ REST | Q02 chỉ chặn streaming thật, không bắt buộc thêm streaming |
| Delete/archive | UX giữ history, lifecycle screen có; TECH chưa lifecycle đầy đủ | Hard/soft delete, transcript retention, official eval retention, FK/tombstone, active op, archived send/restore capability | Q03/04; schema review+API+history read sau delete; R07 OPEN |
| Multi-device remote lifecycle | GET/version/owner và foreground refresh | Send vs remote delete/archive race; conflict outcome, completion after delete, invalidation, removed route/cache handling | Q11+Q03/05; AC27, không tự restore |
| Multi-device concurrent turn | Idempotent same intent; version-sensitive actions | Server ordering, parallel turns/eval, context version winner/conflict; same-key replay và2 intents khác key | Q11+Q05; AC28, không chọn bằng clock thiết bị |
| Retry/idempotency | Same key/payload replay; different payload409; pending retriable | Window/TTL/expiration response, operation lookup/reconciliation mechanism, clientID↔serverID, process-death identity retention | Q05; timeout-after-commit và retry không duplicate; không tự bịa endpoint |
| Pagination | Cursor stable order+ID tie-breaker, owner/filter binding | Global thread/archived list, ordering across remote writes, cursor invalid/expired, refresh/delete/restore race, count semantics | Q06/11; AC15/29; không total từ page length |
| Room cache | Read cache, server authority, owner scope, SWR; offline item manual draft riêng | Chat cache retention/purge/TTL, lifecycle tombstone visibility, account logout/switch cleanup, chat draft persistence | Q06/11; AC16/29; manual item draft không tự cho phép chat outbox |
| Reconnect/foreground | Refresh khi mở/foreground/user refresh/mutation | Fetch order/capability/unknown-op reconciliation khi lifecycle đã đổi; exact guarantees cần accepted contract | Q05/06/11; no autoPOST/replay |

Không mặc định realtime push/WebSocket/periodic WorkManager sync. Refresh baseline có thể đủ nhu cầu một số flow; lựa chọn cụ thể phải dựa contract, không tự chốt ở handoff.

## Evidence để đóng từng Q
Mỗi Q lưu owner-role, approved contract/ADR hoặc source revision, endpoint/schema semantics liên quan, backward compatibility nếu có, AC/test result cần thiết và scope capability được mở. Product UX Approved không cần duyệt lại; một contract còn mở chỉ được đóng bởi bằng chứng tương ứng. Tất cả Q01–Q11 hiện OPEN/PARTIALLY SPECIFIED; phần baseline đã có tiếp tục áp dụng. Q07 tách missing decision bodies khỏi missing visual assets; không đánh đồng2 loại thiếu.

## Phạm vi freshness
SPEC/TECH02/03 dùng fetch đã kiểm ở lượt v0.2 cùng ngày24/10/2026, nội dung khớp snapshots; lượt v0.3 không claim đã fetch lại chúng lần nữa. TECH01/DS/MyItems là snapshots/recovery evidence local. Links nguồn hiện hữu trong sources và references, không tự tạo revision mới.
