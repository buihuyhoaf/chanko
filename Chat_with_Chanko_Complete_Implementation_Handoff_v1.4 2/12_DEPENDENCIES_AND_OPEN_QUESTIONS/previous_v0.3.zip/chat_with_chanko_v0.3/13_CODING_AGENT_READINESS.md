# Coding Agent Readiness Checklist

**Overall: NOT READY FOR IMPLEMENTATION.** Không có authorization viết code trong nhiệm vụ này. Readiness tài liệu không phải build/runtime pass.

| Gate | Status | Bằng chứng / điều kiện còn thiếu |
|---|---|---|
| Scope và baselines giữ nguyên | PASS — DOCUMENT | Không app/PR/migration/Drive edits; original hashes QA |
|34 quyết định có body/option | BLOCKED |0 VERIFIED,34 PARTIAL, R01 |
|34×6 traceability | BLOCKED |204 cells INSUFFICIENT EVIDENCE; không gán AC tự viết |
| UX coverage đọc được | PASS — DOCUMENT ONLY |11 states, pre-verdict, early intent, AC01–29; placement chưa body vẫn P |
| Portable known dependencies | PASS — DOCUMENT ONLY | DS/MyItems recovery/dummy/license, QA paths/checksums; reference docs không runtime bundle |
| Free Chat real | BLOCKED Q01 | Item-nullability/context/lists/reuse/new chưa contract |
| Item REST send/evaluate | BLOCKED Q05/Q08/Q11 | Baseline transport có; actual repo/API + retry window/operation/concurrency chưa đủ |
| Streaming thật | BLOCKED Q02 | Chưa override REST; không cần triển khai nếu giữ baseline REST |
| Delete/Archive/Restore thật | BLOCKED Q03/Q04/Q11 | R07; retention/FK/multi-device active-op/history read proof |
| History/pagination/cache | BLOCKED Q06/Q11 | Global list/lifecycle invalidation/retention cần contract |
| Ready/Postponed/archived item writes | BLOCKED Q10 | MyItems C01/C02, không clear do chỉ vào chat |
| Canonical/visual parity | BLOCKED Q07/Q09 | Missing34 bodies và missing visual/canonical là2 gates riêng |
| Coding standards/repo/build | BLOCKED Q08 | Repo conventions/API actual và commands chưa xác minh |
| Runtime/contract/a11y tests | NOT RUN | Không repo/app được implement; AC là plan |

Không dùng PASS DOCUMENT để bật real capabilities. Prototype text-only có nhãn fake có thể lập kế hoạch bằng tài liệu này; chỉ thực hiện khi có nhiệm vụ implementation riêng, không gọi Approved parity hay production-ready.

Chỉ đổi tổng thể READY FOR IMPLEMENTATION khi body34 được VERIFIED/map6 tài liệu, conflict/missing coverage liên quan xử lý và các Q blocker trong implementation scope có accepted contract/evidence; missing visual phải được ghi đúng scope thay vì giả canonical. Checklist sign-off phải nêu capability được mở, feature deferred và evidence; không bỏ blocker bằng cách đổi nhãn.
