# Asset Manifest
Không tạo asset mới trong nhiệm vụ này. Canonical/v0.2 phải có provenance; mô tả mèo trắng không đủ để xác nhận một file là canonical.

| Asset ID logic | Dùng ở đâu | Status / nguồn | Fallback và release gate |
|---|---|---|---|
| CHANKO-CANONICAL-NEUTRAL | BUY card, contextual companion, lỗi nhẹ | Chưa xác minh file canonical trong workspace | Text-only; chặn final visual sign-off, không thay mèo |
| CHANKO-CANONICAL-IDLE | Empty/Free Chat | Chưa xác minh | Giữ lời mời text |
| CHANKO-CANONICAL-THINKING | Loading | Chưa xác minh | Spinner chuẩn + label; không mascot thay thế |
| CHANKO-CANONICAL-SUPPORTIVE | Error/offline nếu Approved screen dùng | Chưa xác minh | Banner text; placement là P |
| CHANKO-STATIC-FALLBACK | Reduce motion/load failure | Cần canonical static cùng model | Không bounce/animation giả |
| CHAT-V0.2-SCREENS-TOKENS | 11 states visual parity | User xác nhận Approved, chưa truy xuất file | Không tuyên bố pixel parity từ Design System v1.0 |
| NUNITO | UI text/numbers | DS yêu cầu; chưa có font/license trong bundle | Dùng asset hợp lệ từ repo đích, kiểm tra glyph Việt/OFL |
| MATERIAL-SYMBOLS-ROUNDED | Back/history/more/send/archive/delete | Family theo DS; glyph mapping P | Dùng registry app và license, ≥48dp hit target |
| PRODUCT-DUMMY | Item chip/picker thumbnail khi thiếu ảnh | Có ở dependencies/product_placeholder_256.png | Neutral placeholder; không mascot trong product media |
| OPTIONAL-SOUND | Tương tác mascot rõ ràng | Starter pack là synthesized prototype, không canonical visual/không production sign-off | Mặc định tắt; không tự tích hợp, không celebration |
| HOME-HANDOFF-CANDIDATE | Có thể chứa asset canonical cần xác minh | Drive chanko-home-handoff.zip; đã thấy metadata, raw fetch trả file reference, chưa inspect bytes | Không tuyên bố nội dung ZIP hoặc canonical đã xác minh |

Candidate Home ZIP: https://drive.google.com/file/d/1p4nEVvhqA2TcWBO9cToTxU8Eclf-VWjT/view
Metadata: ZIP, 8.603.525 bytes, modified 2026-10-20T14:26:53.374Z. File reference từ connector không phải đường dẫn local. Không đóng gói bearer download URL.

## Metadata cần ghi khi nhận asset thật
Canonical asset ID/version, owner approval/source link, filename và checksum, file format, source pixel dimensions/density variants, alpha, crop/anchor/safe bounds, static/reduced-motion alternative, emotion mapping, usage/license và performance budget. Không đoán resolution hay dung lượng giới hạn thành Approved.

## QA trước final visual acceptance
So sánh model/tỷ lệ/mắt/vật liệu/ánh sáng với canonical đã xác nhận. Kiểm alpha trên cream/pastel; không stretch/crop tai/mặt. Message/copy phải là text thật, không nằm trong bitmap. BUY giữ neutral, không confetti/sparkle tạo cảm giác khuyến khích mua. Không dùng chó, mèo stock hoặc imagegen tái tạo Chanko.

## Dependency packaging v0.3
Design System tại dependencies/design_system_v1_0.txt, My Items Recovery tại dependencies/my_items/sources/approved_ux_recovery_baseline.md. Đây là reference evidence local, không thêm approval cho visual Chat0.2. Dummy có license riêng tại dependencies/PRODUCT_PLACEHOLDER_LICENSE.txt. R05 chỉ đóng lỗi portable dependency đã biết; canonical/Nunito/visual0.2 vẫn thiếu nên final visual acceptance chưa đạt.
